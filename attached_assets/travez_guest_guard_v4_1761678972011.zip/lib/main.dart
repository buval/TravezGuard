
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'data/users_repo.dart';
import 'data/app_state.dart';
import 'features/auth/login_screen.dart';
import 'features/auth/signup_screen.dart';
import 'features/guest/guest_home_screen.dart';
import 'features/home/home_screen.dart';

void main() {
  runApp(const TravezApp());
}

final _router = GoRouter(
  initialLocation: '/login',
  routes: [
    GoRoute(path: '/login', builder: (c, s) => const LoginScreen()),
    GoRoute(path: '/signup', builder: (c, s) => const SignUpScreen()),
    GoRoute(path: '/guest', builder: (c, s) => const GuestHomeScreen()),
    GoRoute(path: '/home', builder: (c, s) => const HomeScreen()),
  ],
);

class TravezApp extends StatelessWidget {
  const TravezApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'TravEZ',
      theme: ThemeData(
        colorSchemeSeed: const Color(0xFF1db954),
        useMaterial3: true,
      ),
      routerConfig: _router,
    );
  }
}
