
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../data/users_repo.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});
  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final u = TextEditingController();
  final p = TextEditingController();
  final e = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Create Account')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(controller: u, decoration: const InputDecoration(labelText: 'Username')),
          const SizedBox(height: 8),
          TextField(controller: e, decoration: const InputDecoration(labelText: 'Email')),
          const SizedBox(height: 8),
          TextField(controller: p, decoration: const InputDecoration(labelText: 'Password'), obscureText: true),
          const SizedBox(height: 12),
          SizedBox(
            height: 48,
            child: FilledButton(
              onPressed: () async {
                final ok = await UsersRepo.signUp(u.text.trim(), p.text, e.text.trim());
                if (!ok) {
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Username already exists.')));
                  return;
                }
                final sp = await SharedPreferences.getInstance();
                await sp.setBool('loggedIn', true);
                await sp.setBool('guest', false);
                if (!context.mounted) return;
                context.go('/home');
              },
              child: const Text('Create & Continue'),
            ),
          ),
        ],
      ),
    );
  }
}
