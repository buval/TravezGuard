
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../data/users_repo.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final u = TextEditingController();
  final p = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Log In')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(controller: u, decoration: const InputDecoration(labelText: 'Username', hintText: 'e.g. Arash')),
          const SizedBox(height: 8),
          TextField(controller: p, decoration: const InputDecoration(labelText: 'Password'), obscureText: true),
          const SizedBox(height: 12),
          SizedBox(
            height: 48,
            child: FilledButton(
              onPressed: () async {
                final ok = await UsersRepo.validate(u.text.trim(), p.text);
                if (!ok) {
                  if (!context.mounted) return;
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Invalid username or password, or account not confirmed.')));
                  return;
                }
                final sp = await SharedPreferences.getInstance();
                await sp.setBool('loggedIn', true);
                await sp.setBool('guest', false);
                if (!context.mounted) return;
                context.go('/home');
              },
              child: const Text('Log In'),
            ),
          ),
          const SizedBox(height: 8),
          SizedBox(
            height: 48,
            child: OutlinedButton(
              onPressed: () async {
                final sp = await SharedPreferences.getInstance();
                await sp.setBool('guest', true);
                await sp.setBool('loggedIn', false);
                if (!context.mounted) return;
                context.go('/guest');
              },
              child: const Text('Guest Login'),
            ),
          ),
          const SizedBox(height: 8),
          Align(
            alignment: Alignment.center,
            child: TextButton(
              onPressed: ()=>context.go('/signup'),
              child: const Text('Create account'),
            ),
          ),
        ],
      ),
    );
  }
}
