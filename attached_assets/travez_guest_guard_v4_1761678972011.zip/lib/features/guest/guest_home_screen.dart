
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:flutter_typeahead/flutter_typeahead.dart';
import 'package:http/http.dart' as http;
import '../../data/app_state.dart';

class Promo {
  final String title;
  final String assetImage;
  Promo(this.title, this.assetImage);
}

// simple in-app promos dataset to use as hotels
class Promos {
  static List<Promo> forCity(String city) {
    return List.generate(6, (i) => Promo('Hotel ${(i+1)} in $city', 'assets/images/promo${(i%4)+1}.png'));
  }
}

class GuestHomeScreen extends StatefulWidget {
  const GuestHomeScreen({super.key});
  @override
  State<GuestHomeScreen> createState() => _GuestHomeState();
}

class _GuestHomeState extends State<GuestHomeScreen> {
  final TextEditingController _cityCtl = TextEditingController();
  List<String> _cities = [];
  String? _city;
  List<Map<String,String>> _landmarks = [];
  List<Promo> _hotels = [];
  bool _loading = true;
  String _weather = 'Current: 18°C  ·  Wind: 3 m/s  ·  Clear skies (mock)';

  @override
  void initState() { super.initState(); _init(); }

  Future<void> _init() async {
    final txt = await rootBundle.loadString('assets/data/cities.json');
    final data = jsonDecode(txt) as Map<String, dynamic>;
    _cities = List<String>.from(data['cities'] as List);
    _city = _cities.firstWhere((e) => e.startsWith('Winnipeg'), orElse: () => _cities.first);
    _cityCtl.text = _city!;
    await _loadForCity();
    await _refreshWeatherOnline(_city!.split(',').first);
    setState(() => _loading = false);
  }

  Future<List<String>> _onlineSuggestions(String pattern) async {
    try {
      final uri = Uri.parse('https://geocoding-api.open-meteo.com/v1/search?name=${Uri.encodeComponent(pattern)}&count=8&language=en&format=json');
      final r = await http.get(uri);
      if (r.statusCode == 200) {
        final data = jsonDecode(r.body) as Map<String, dynamic>;
        final res = (data['results'] ?? []) as List;
        final out = <String>[];
        for (final row in res) {
          final name = row['name'];
          final country = row['country'];
          if (name != null && country != null) {
            out.add('$name, $country');
          }
        }
        return out;
      }
    } catch (_) {}
    return [];
  }

  Future<void> _refreshWeatherOnline(String name) async {
    try {
      final sUri = Uri.parse('https://geocoding-api.open-meteo.com/v1/search?name=${Uri.encodeComponent(name)}&count=1&language=en&format=json');
      final sResp = await http.get(sUri);
      if (sResp.statusCode == 200) {
        final data = jsonDecode(sResp.body);
        final results = (data['results'] ?? []) as List;
        if (results.isNotEmpty) {
          final lat = results[0]['latitude'];
          final lon = results[0]['longitude'];
          final wUri = Uri.parse('https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current_weather=true');
          final wResp = await http.get(wUri);
          if (wResp.statusCode == 200) {
            final w = jsonDecode(wResp.body);
            final cw = w['current_weather'];
            if (cw != null) {
              final temp = cw['temperature'];
              final wind = cw['windspeed'];
              final code = cw['weathercode'];
              _weather = 'Current: ${temp}°C  ·  Wind: ${wind} km/h  ·  Code $code';
              setState((){});
              return;
            }
          }
        }
      }
    } catch (_) {}
    // keep mock if fails
  }

  Future<void> _loadForCity() async {
    final c = (_city ?? _cities.first).split(',').first;
    AppState.currentCity = c;

    final sTxt = await rootBundle.loadString('assets/data/sightseeing.json');
    final s = jsonDecode(sTxt) as Map<String, dynamic>;
    final list = (s[c] ?? []) as List;
    _landmarks = list.map((e) => {'title': e['title'].toString(), 'desc': e['desc'].toString()}).toList();

    _hotels = Promos.forCity(c);
    setState(() {});
  }

  void _requireSignIn(String what) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (ctx) {
        final email = TextEditingController();
        return Padding(
          padding: EdgeInsets.only(
            left: 16, right: 16, top: 12,
            bottom: 16 + MediaQuery.of(ctx).viewInsets.bottom,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Sign in required', style: Theme.of(ctx).textTheme.titleLarge),
              const SizedBox(height: 6),
              Text('To complete booking or payment for “$what”, please sign in or create a free account.'),
              const SizedBox(height: 12),
              TextField(
                controller: email,
                keyboardType: TextInputType.emailAddress,
                decoration: const InputDecoration(labelText: 'Email (for confirmation)', hintText: 'you@example.com'),
              ),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: FilledButton(onPressed: (){ Navigator.pop(ctx); if (!mounted) return; Navigator.of(context).pushNamed('/login'); }, child: const Text('Sign In'))),
                  const SizedBox(width: 12),
                  Expanded(child: OutlinedButton(onPressed: (){ Navigator.pop(ctx); if (!mounted) return; Navigator.of(context).pushNamed('/signup'); }, child: const Text('Create Account'))),
                ],
              ),
              const SizedBox(height: 8),
              Center(child: TextButton(onPressed: ()=> Navigator.pop(ctx), child: const Text('Cancel'))),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    return Scaffold(
      appBar: AppBar(title: const Text('Guest')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
        children: [
          Text('Welcome user', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Text('Start typing location name:', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 6),
          TypeAheadField<String>(
          suggestionsCallback: (pattern) async {
            if (pattern.trim().length < 2) {
              final lower = pattern.toLowerCase();
              return _cities.where((c) => c.toLowerCase().contains(lower)).take(8).toList();
            }
            final online = await _onlineSuggestions(pattern);
            if (online.isNotEmpty) return online;
            final lower = pattern.toLowerCase();
            return _cities.where((c) => c.toLowerCase().contains(lower)).take(8).toList();
          },
          builder: (context, controller, focusNode) {
            // keep our local controller in sync (optional)
            controller.text = controller.text.isEmpty ? (_city ?? '') : controller.text;
            _cityCtl.value = controller.value;
            return TextField(
              controller: controller,
              focusNode: focusNode,
              decoration: const InputDecoration(
                labelText: 'City, Country',
                hintText: 'Start typing...',
              ),
            );
          },
          itemBuilder: (context, suggestion) => ListTile(
            leading: const Icon(Icons.location_on_outlined),
            title: Text(suggestion),
          ),
          onSelected: (suggestion) async {
            _city = suggestion;
            _cityCtl.text = suggestion;
            await _loadForCity();
            await _refreshWeatherOnline(suggestion.split(',').first);
            setState((){});
          },
        ),
          const SizedBox(height: 20),

          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children:[
            Text('Hotel offers', style: Theme.of(context).textTheme.titleMedium),
            TextButton(onPressed: (){
              showModalBottomSheet(context: context, showDragHandle: true, builder: (c){
                return ListView(padding: const EdgeInsets.all(12), children: [
                  const Padding(padding: EdgeInsets.all(8), child: Text('All Hotel Offers', style: TextStyle(fontWeight: FontWeight.w700))),
                  ..._hotels.map((h)=> ListTile(
                    leading: const Icon(Icons.hotel),
                    title: Text(h.title),
                    trailing: FilledButton.tonal(onPressed: ()=>_requireSignIn(h.title), child: const Text('Book')),
                  )),
                  const SizedBox(height: 12),
                ]);
              });
            }, child: const Text('See more')),
          ]),
          const SizedBox(height: 8),
          GridView.builder(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 0.82),
            itemCount: _hotels.length > 4 ? 4 : _hotels.length,
            shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (context, i){
              final h = _hotels[i];
              return Card(
                clipBehavior: Clip.antiAlias,
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
                  Expanded(child: Image.asset(h.assetImage, fit: BoxFit.cover, width: double.infinity)),
                  Padding(padding: const EdgeInsets.all(8), child: Text(h.title, maxLines: 2, overflow: TextOverflow.ellipsis)),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
                    child: Row(children:[
                      Expanded(child: FilledButton.tonal(onPressed: ()=>_requireSignIn(h.title), child: const Text('Book'))),
                      const SizedBox(width: 8),
                      Expanded(child: OutlinedButton(onPressed: ()=>_requireSignIn(h.title), child: const Text('Pay'))),
                    ]),
                  ),
                ]),
              );
            },
          ),
          const SizedBox(height: 20),

          Text('Weather', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.green.withOpacity(0.06), borderRadius: BorderRadius.circular(12)), child: Text(_weather)),
          const SizedBox(height: 20),

          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children:[
            Text('Landmark offers', style: Theme.of(context).textTheme.titleMedium),
            TextButton(onPressed: (){
              showModalBottomSheet(context: context, showDragHandle: true, builder: (c){
                return ListView(padding: const EdgeInsets.all(12), children: [
                  const Padding(padding: EdgeInsets.all(8), child: Text('More Landmarks', style: TextStyle(fontWeight: FontWeight.w700))),
                  ..._landmarks.map((l)=> ListTile(
                    leading: const Icon(Icons.place_outlined),
                    title: Text(l['title']!),
                    trailing: FilledButton.tonal(onPressed: ()=>_requireSignIn(l['title']!), child: const Text('Book')),
                  )),
                  const SizedBox(height: 12),
                ]);
              });
            }, child: const Text('See more')),
          ]),
          const SizedBox(height: 8),
          GridView.builder(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 0.82),
            itemCount: _landmarks.length > 4 ? 4 : _landmarks.length,
            shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            itemBuilder: (context, i){
              final l = _landmarks[i];
              return Card(
                clipBehavior: Clip.antiAlias,
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[
                  Expanded(child: Image.asset('assets/images/promo${(i%4)+1}.png', fit: BoxFit.cover, width: double.infinity)),
                  Padding(padding: const EdgeInsets.all(8), child: Text(l['title']!, maxLines: 2, overflow: TextOverflow.ellipsis)),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
                    child: Row(children:[
                      Expanded(child: FilledButton.tonal(onPressed: ()=>_requireSignIn(l['title']!), child: const Text('Book'))),
                      const SizedBox(width: 8),
                      Expanded(child: OutlinedButton(onPressed: ()=>_requireSignIn(l['title']!), child: const Text('Pay'))),
                    ]),
                  ),
                ]),
              );
            },
          ),
        ],
      ),
    );
  }
}
