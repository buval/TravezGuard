
class AppState {
  static String currentCity = 'Winnipeg';
}
