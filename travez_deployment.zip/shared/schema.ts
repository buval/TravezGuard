import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  date,
  boolean,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table - Required for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - Supports both Replit Auth (OIDC) and Username/Password
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: varchar("username").unique(), // Optional for Replit Auth users
  password: varchar("password"), // Hashed password (only for username/password users)
  email: varchar("email"),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"), // For Replit Auth
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Destinations table - Predefined travel destinations
export const destinations = pgTable("destinations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  country: text("country").notNull(),
  description: text("description").notNull(),
  imageUrl: text("image_url").notNull(),
  category: text("category").notNull(), // e.g., "beach", "mountain", "city", "cultural", "adventure"
  featured: boolean("featured").default(false),
  latitude: text("latitude"), // Latitude coordinate for Amadeus API calls
  longitude: text("longitude"), // Longitude coordinate for Amadeus API calls
  visaRequirements: text("visa_requirements"), // Visa information for travelers
  travelDocuments: text("travel_documents"), // Required documents and entry requirements
  climate: text("climate"), // Climate type and general weather patterns
  bestMonths: text("best_months"), // Best months to visit
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertDestinationSchema = createInsertSchema(destinations).omit({
  id: true,
  createdAt: true,
});

export type InsertDestination = z.infer<typeof insertDestinationSchema>;
export type Destination = typeof destinations.$inferSelect;

// Trips table - User-created trips
export const trips = pgTable("trips", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: 'cascade' }),
  destinationId: varchar("destination_id").references(() => destinations.id),
  title: text("title").notNull(),
  startDate: date("start_date").notNull(),
  endDate: date("end_date").notNull(),
  notes: text("notes"),
  budget: integer("budget"), // Total budget for the trip in USD
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertTripSchema = createInsertSchema(trips).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertTrip = z.infer<typeof insertTripSchema>;
export type Trip = typeof trips.$inferSelect;

// Itinerary items table - Day-by-day activities for trips
export const itineraryItems = pgTable("itinerary_items", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tripId: varchar("trip_id").notNull().references(() => trips.id, { onDelete: 'cascade' }),
  day: integer("day").notNull(), // Day number in the trip (1, 2, 3, etc.)
  time: text("time"), // e.g., "09:00 AM", "14:30"
  title: text("title").notNull(),
  description: text("description"),
  location: text("location"),
  type: text("type").notNull(), // e.g., "activity", "dining", "accommodation", "transport"
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertItineraryItemSchema = createInsertSchema(itineraryItems).omit({
  id: true,
  createdAt: true,
});

export type InsertItineraryItem = z.infer<typeof insertItineraryItemSchema>;
export type ItineraryItem = typeof itineraryItems.$inferSelect;

// Expenses table - Track trip expenses
export const expenses = pgTable("expenses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  tripId: varchar("trip_id").notNull().references(() => trips.id, { onDelete: 'cascade' }),
  category: text("category").notNull(), // e.g., "accommodation", "food", "transport", "activities", "shopping", "other"
  amount: integer("amount").notNull(), // Amount in USD cents (to avoid floating point issues)
  date: date("date").notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertExpenseSchema = createInsertSchema(expenses).omit({
  id: true,
  createdAt: true,
});

export type InsertExpense = z.infer<typeof insertExpenseSchema>;
export type Expense = typeof expenses.$inferSelect;

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  trips: many(trips),
}));

export const destinationsRelations = relations(destinations, ({ many }) => ({
  trips: many(trips),
}));

export const tripsRelations = relations(trips, ({ one, many }) => ({
  user: one(users, {
    fields: [trips.userId],
    references: [users.id],
  }),
  destination: one(destinations, {
    fields: [trips.destinationId],
    references: [destinations.id],
  }),
  itineraryItems: many(itineraryItems),
  expenses: many(expenses),
}));

export const itineraryItemsRelations = relations(itineraryItems, ({ one }) => ({
  trip: one(trips, {
    fields: [itineraryItems.tripId],
    references: [trips.id],
  }),
}));

export const expensesRelations = relations(expenses, ({ one }) => ({
  trip: one(trips, {
    fields: [expenses.tripId],
    references: [trips.id],
  }),
}));

// Flight Bookings table - Store flight reservations
export const flightBookings = pgTable("flight_bookings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id, { onDelete: 'cascade' }),
  bookingReference: varchar("booking_reference").notNull().unique(), // e.g., "TRV-ABC123"
  flightData: jsonb("flight_data").notNull(), // Store complete flight offer data
  totalPrice: integer("total_price").notNull(), // Total in cents (USD)
  status: varchar("status").notNull().default("pending"), // pending, confirmed, cancelled
  paymentIntentId: varchar("payment_intent_id"), // Stripe payment intent ID
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertFlightBookingSchema = createInsertSchema(flightBookings).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertFlightBooking = z.infer<typeof insertFlightBookingSchema>;
export type FlightBooking = typeof flightBookings.$inferSelect;

// Passengers table - Store passenger information for bookings
export const passengers = pgTable("passengers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  bookingId: varchar("booking_id").notNull().references(() => flightBookings.id, { onDelete: 'cascade' }),
  passengerType: varchar("passenger_type").notNull(), // "adult", "child", "infant"
  title: varchar("title").notNull(), // Mr, Mrs, Ms, Dr
  firstName: varchar("first_name").notNull(),
  lastName: varchar("last_name").notNull(),
  dateOfBirth: date("date_of_birth"),
  email: varchar("email"),
  phone: varchar("phone"),
  passportNumber: varchar("passport_number"),
  passportExpiry: date("passport_expiry"),
  passportCountry: varchar("passport_country"),
  seatNumber: varchar("seat_number"), // e.g., "12A"
  seatPreference: varchar("seat_preference"), // "window", "aisle", "middle"
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertPassengerSchema = createInsertSchema(passengers).omit({
  id: true,
  createdAt: true,
});

export type InsertPassenger = z.infer<typeof insertPassengerSchema>;
export type Passenger = typeof passengers.$inferSelect;

// Amadeus API Flight Types
export interface FlightSegment {
  departure: {
    iataCode: string;
    at: string;
  };
  arrival: {
    iataCode: string;
    at: string;
  };
  carrierCode: string;
  number: string;
  duration: string;
  aircraft?: {
    code?: string;
  };
}

export interface FlightItinerary {
  duration: string;
  segments: FlightSegment[];
}

export interface FlightPrice {
  total: string;
  currency: string;
}

export interface FlightOffer {
  id: string;
  price: FlightPrice;
  itineraries: FlightItinerary[];
  validatingAirlineCodes: string[];
}

// Flight Booking Relations
export const flightBookingsRelations = relations(flightBookings, ({ one, many }) => ({
  user: one(users, {
    fields: [flightBookings.userId],
    references: [users.id],
  }),
  passengers: many(passengers),
}));

export const passengersRelations = relations(passengers, ({ one }) => ({
  booking: one(flightBookings, {
    fields: [passengers.bookingId],
    references: [flightBookings.id],
  }),
}));
