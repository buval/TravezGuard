
import 'dart:async';

class UsersRepo {
  static final Map<String, (String password, bool confirmed)> _users = {
    'Arash': ('test', true),
  };

  static Future<bool> validate(String user, String pass) async {
    await Future.delayed(const Duration(milliseconds: 200));
    final rec = _users[user];
    if (rec == null) return false;
    return rec.$1 == pass && rec.$2 == true;
  }

  static Future<bool> signUp(String user, String pass, String email) async {
    await Future.delayed(const Duration(milliseconds: 300));
    if (_users.containsKey(user)) return false;
    _users[user] = (pass, true); // auto-confirm for test purposes
    return true;
  }
}
